﻿// 'C:\Users\kjs\Documents\Visual Studio 2012\Projects\MvcApplication1\MvcApplication1\Models\Model1.edmx' 모델에 대해 기본 코드를 생성할 수 없습니다.
// 기본 코드 생성 기능을 사용하려면 '코드 생성 전략' 디자이너
// 속성 값을 대체 값으로 변경하십시오. 이 속성은 디자이너에 모델이
// 열려 있는 경우 [속성] 창에서 사용할 수 있습니다.