

//SIDE MENU Accordion
  $(document).ready(function() {
	$('#main_menu [data-accordion]').accordion();
	$('.tablist1 [data-accordion]').accordion();
  });

//SEARCHBAR
$(document).ready(function(){
	$(".btn_search").click(function(){
		$(this).toggleClass("open");
		$(".searchbar").toggleClass("open");
	});
});

//GO TO TOP
$(function() {
     $("#gototop").on("click",function(e){
               $('html,body').animate({
                         scrollTop:0
                         },500);
     });

});
