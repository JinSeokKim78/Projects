﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Ajax;
using MvcApplication1.Models;
using System.Web.Security;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.IO;
using System.Net;
using System.Text;
using System.Windows.Forms;

namespace MvcApplication1.Controllers
{
    public class HomeController : Controller
    {

        public ActionResult Index(string IndexPctpwd)
        {

            HttpCookie cookie = Request.Cookies["Login"];

            if (cookie != null)
            {
                string ctcode = HttpUtility.UrlDecode(cookie.Values["CtCode"]);
                string president = HttpUtility.UrlDecode(cookie.Values["President"]);
                string mobile = HttpUtility.UrlDecode(cookie.Values["Mobile"]);
                string newgubun = HttpUtility.UrlDecode(cookie.Values["NewGubun"]);
                string cardno = HttpUtility.UrlDecode(cookie.Values["CardNo"]);
                ViewData["ctcode"] = ctcode;
                ViewData["president"] = president;
                ViewData["mobile"] = mobile.Replace("-","");
                ViewData["userpoint"] = "0";
                ViewData["useremoney"] = "0";
                ViewData["cardno"] = cardno;

                //선입금&포인트
                using (SqlConnection dbCon = new SqlConnection(WebConfigurationManager.ConnectionStrings["Source"].ConnectionString))
                {
                    string sql = "select userpoint, (select useremoney from dbo.fn_customer_emoney(corpcode,ctcode)) as [useremoney] from table_corp_customer where ctcode ='" + ctcode + "'";

                    using(SqlCommand cmd = new SqlCommand(sql,dbCon))
                    {
                        try
                        {
                            dbCon.Open();

                            using (SqlDataReader rdr = cmd.ExecuteReader())
                            {
                                while (rdr.Read())
                                {
                                    string userpoint = rdr["userpoint"].ToString();
                                    string useremoney = rdr["useremoney"].ToString();
                                    ViewData["userpoint"] = userpoint;
                                    ViewData["useremoney"] = useremoney;
                                }
                            }

                        }
                        catch(Exception ex)
                        {
                            //
                        }
                    }
 
                }

                if (newgubun == "N")
                {
                    return RedirectToAction("ChangePW", "Home", new { ChangePWPctpwd = IndexPctpwd });
                }
                else
                {
                    return View();
                }
            }
            else
            {
                return RedirectToAction("Login", "Home");
            }

        }

        public ActionResult ChangePW(string ChangePWPctpwd)
        {
            ViewData["ChangePWPctpwd"] = ChangePWPctpwd;
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ChangePW(table_Corp_Customer_ex c, string returnUrl)
        {

            if (ModelState.IsValid)
            {
                try
                {
                    using (CustomerModelEntities db = new CustomerModelEntities())
                    {

                        HttpCookie cookie = Request.Cookies["Login"];
                        string ctcode="";
                        string ctpwd="";

                        if (cookie != null)
                        {
                            ctcode = HttpUtility.UrlDecode(cookie.Values["CtCode"]);
                        }
                        else
                        {
                            return RedirectToAction("Login", "Home");
                        }

                        if (c.CtPwd_O == null)
                        {
                            return RedirectToAction("Message", "Home", new { gbn = "3" });
                        }

                        if (c.CtPwd_N != c.CtPwd_C)
                        {
                            return RedirectToAction("Message", "Home", new { gbn = "4" });
                        }

                        ctpwd = zenFramework.Cryptogram.Cipher.Encrypt(c.CtPwd_O, ctcode);
                        var v = db.table_Corp_Customer.Where(m => m.CtCode.Equals(ctcode) && m.CtPwd.Equals(ctpwd)).FirstOrDefault();
                        if (v != null)
                        {
                            v.CtPwd = zenFramework.Cryptogram.Cipher.Encrypt(c.CtPwd_N, ctcode);
                            db.SaveChanges();
                            return RedirectToAction("Message", "Home", new { gbn = "1", pCtCode = ctcode });
                        }
                        else
                        {
                            return RedirectToAction("Message", "Home", new { gbn = "5" });
                        }

                    }

                }
                catch (InvalidOperationException ex)
                {
                    //
                }

            }
            return View(c);
        }

        public ActionResult Login(string pCtCode)
        {
            HttpCookie ckctcode = Request.Cookies["MemberCode"];

            if (ckctcode != null)
            {
                string ctcode = "";
                ctcode = HttpUtility.UrlDecode(ckctcode.Values["CkCtCode"]);
                ViewData["CkCtCode"] = ctcode;
            }
            else
            {
                ViewData["CkCtCode"] = pCtCode;
            }
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(table_Corp_Customer c, string returnUrl)
        {

            if (ModelState.IsValid)
            {
                try
                {
                    using (CustomerModelEntities db = new CustomerModelEntities())
                    {
                        string ctpwd = "";
                        ctpwd = zenFramework.Cryptogram.Cipher.Encrypt(c.CtPwd, c.CtCode);
                        var v = db.table_Corp_Customer.Where(m => m.CtCode.Equals(c.CtCode) && m.CtPwd.Equals(ctpwd)).FirstOrDefault();
                        if (v != null)
                        {

                            HttpCookie cookie = new HttpCookie("Login");

                            /***********************************************************************************************************************회원카드*/
                            using (SqlConnection dbCon = new SqlConnection(WebConfigurationManager.ConnectionStrings["Source"].ConnectionString))
                            {
                                string sql = "select top 1 cardno from table_corp_customer_card where ctcode = '" + c.CtCode + "'";

                                using (SqlCommand cmd = new SqlCommand(sql, dbCon))
                                {
                                    try
                                    {
                                        dbCon.Open();
                                        string cardno = "";

                                        using (SqlDataReader rdr = cmd.ExecuteReader())
                                        {
                                            while (rdr.Read())
                                            {
                                                cardno = rdr["cardno"].ToString();
                                                cookie.Values.Add("CardNo", HttpUtility.UrlEncode(cardno));
                                            }
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        //
                                    }
                                }
                            }

                            HttpCookie chctcode = Request.Cookies["MemberCode"];
                            if (chctcode == null)
                            {
                                HttpCookie ckctcode = new HttpCookie("MemberCode");
                                ckctcode.Values.Add("CkCtCode", HttpUtility.UrlEncode(v.CtCode));
                                ckctcode.Expires = DateTime.Now.AddMonths(5);
                                HttpContext.Response.Cookies.Add(ckctcode);
                            }
                            else
                            {
                                //********************************************************************************ID 변경
                                string gckctcode = HttpUtility.UrlDecode(chctcode.Values["CkCtCode"]);
                                if (gckctcode != v.CtCode)
                                {
                                    var nchctcode = new HttpCookie("MemberCode")
                                    {
                                        Expires = DateTime.Now.AddHours(-1),
                                        Value = null
                                    };
                                    HttpContext.Response.Cookies.Add(nchctcode);

                                    HttpCookie ckctcode = new HttpCookie("MemberCode");
                                    ckctcode.Values.Add("CkCtCode", HttpUtility.UrlEncode(v.CtCode));
                                    ckctcode.Expires = DateTime.Now.AddMonths(5);
                                    HttpContext.Response.Cookies.Add(ckctcode);

                                }
                            }

                            cookie.Values.Add("CtCode", HttpUtility.UrlEncode(v.CtCode));
                            cookie.Values.Add("President", HttpUtility.UrlEncode(v.JoinUserName));
                            cookie.Values.Add("Mobile", HttpUtility.UrlEncode(v.Mobile));

                            if (c.CtPwd.Substring(0, 1).ToUpper() == "N")
                            {
                                cookie.Values.Add("NewGubun", HttpUtility.UrlEncode("N"));
                            }
                            else
                            {
                                cookie.Values.Add("NewGubun", HttpUtility.UrlEncode("Y"));
                            }

                            if (c.RememberMe)
                            {
                                cookie.Expires = DateTime.Now.AddHours(72);
                            }
                            else
                            {
                                cookie.Expires = DateTime.Now.AddHours(1);
                            }

                            HttpContext.Response.Cookies.Add(cookie);
                            return RedirectToAction("Index", "Home", new { IndexPctpwd = c.CtPwd });
                        }
                        else
                        {
                            return RedirectToAction("Message", "Home", new { gbn = "6", pCtCode = c.CtCode });
                        }

                    }

                }
                catch (InvalidOperationException ex)
                {
                    //
                }

            }

            ViewData["CkCtCode"] = c.CtCode;
            ViewData["CkCtPwd"] = c.CtPwd;
            return View();
        }

        public ActionResult Logout(string pCtCode)
        {
            if (Request.Cookies["Login"] != null)
            {
                var cookie = new HttpCookie("Login")
                {
                    Expires = DateTime.Now.AddHours(-1),
                    Value = null
                };
                HttpContext.Response.Cookies.Add(cookie);
            }
            return RedirectToAction("Login", "Home", new { pCtCode = pCtCode });
        }

        public ActionResult Intro()
        {
            return View();
        }

        public ActionResult Message(string gbn, string pCtCode)
        {
            if (gbn == "1")
            {
                ViewData["msg"] = "고객님의 새로운 비밀번호가" + System.Environment.NewLine + "등록되었습니다.";
            }else if(gbn == "2"){
                ViewData["msg"] = "본인인증된 휴대전화로" + System.Environment.NewLine + "회원번호/새로운 비밀번호를 전송했습니다.";
            }
            else if (gbn == "3")
            {
                ViewData["msg"] = "변경 전 비밀번호를 입력바랍니다.";
            }
            else if (gbn == "4")
            {
                ViewData["msg"] = "신규 비밀번호와 재 확인용 비밀번호가 일치하지 않습니다.";
            }
            else if (gbn == "5")
            {
                ViewData["msg"] = "일치하는 회원이 없습니다." + System.Environment.NewLine + "변경 전 비밀번호를 재 확인 바랍니다.";
            }
            else if (gbn == "6")
            {
                ViewData["msg"] = "일치하는 회원이 없습니다." + System.Environment.NewLine + "회원번호 및 비밀번호를 확인 바랍니다.";
            }
            else if (gbn == "7")
            {
                ViewData["msg"] = "이미지가 등록되었습니다.";
            }
            else if (gbn == "8")
            {
                ViewData["msg"] = "일치하는 회원이 없습니다.";
            }
            else if (gbn == "9")
            {
                ViewData["msg"] = "이미지를 등록 바랍니다.";
            }
            else if (gbn == "10")
            {
                ViewData["msg"] = "확장장(jpg/png/gif)를 가지는 이미지를 등록바랍니다.";
            }
            else if (gbn == "11")
            {
                ViewData["msg"] = "오류가 발생되었습니다." + System.Environment.NewLine + "다시등록 바랍니다.";
            }
            else if (gbn == "12")
            {
                ViewData["msg"] = "이미 등록된 이미지가 있습니다.";
            }

            ViewData["gbn"] = gbn;
            ViewData["pctcode"] = pCtCode;
            return View();
        }

        public ActionResult Message_src(string gbn, string pCtCode)
        {
            if (gbn == "1" || gbn == "2" || gbn == "8")
            {
                return RedirectToAction("Logout", "Home", new { pCtCode = pCtCode });
            }
            else if (gbn == "3" || gbn == "4" || gbn == "5")
            {
                return RedirectToAction("ChangePW", "Home");
            }
            else if (gbn == "6")
            {
                return RedirectToAction("Login", "Home", new { pCtCode = pCtCode });
            }
            else if (gbn == "7" || gbn == "9" || gbn == "10" || gbn == "11" || gbn == "12")
            {
                return RedirectToAction("UploadImg", "Home");
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        //사업자회원
        public ActionResult ConfirmMember()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ConfirmMember(table_Corp_Customer_src c, string returnUrl)
        {

            if (ModelState.IsValid)
            {
                try
                {
                    using (CustomerModelEntities db = new CustomerModelEntities())
                    {
                        var sMobileSrc = c.Mobile_src;
                        var sTaxCodeSrc = c.TaxCode_src;

                        sMobileSrc = sMobileSrc.ToString().Replace("-", "");
                        sTaxCodeSrc = sTaxCodeSrc.ToString().Replace("-", "");

                        var v = db.table_Corp_Customer.Where(m => m.Mobile.Replace("-", "").Equals(sMobileSrc) && m.TaxCode.Replace("-", "").Equals(sTaxCodeSrc) && m.IsStatus.Equals("1")).FirstOrDefault();
                        if (v != null)
                        {
                            string rnumber = "";

                            using (SqlConnection dbCon = new SqlConnection(WebConfigurationManager.ConnectionStrings["Source"].ConnectionString))
                            {
                                string sql = "select top 1 Mobile as [phone] from table_corp where corpcode='JangBoGo'";

                                using (SqlCommand cmd = new SqlCommand(sql, dbCon))
                                {
                                    try
                                    {
                                        dbCon.Open();
                                        string sendphone = "";

                                        using (SqlDataReader rdr = cmd.ExecuteReader())
                                        {
                                            while (rdr.Read())
                                            {
                                                sendphone = rdr["phone"].ToString().Replace("-","");

                                                if (sendphone.Length > 8)
                                                {
                                                    String.Format("{0: 0##-###-####}", Convert.ToInt32(sendphone));
                                                }

                                            }
                                        }

                                        /*문자발송 등록***************************************************************************************************/
                                        using (SqlConnection dbSMS = new SqlConnection(WebConfigurationManager.ConnectionStrings["SMS"].ConnectionString))
                                        {

                                            try
                                            {

                                                int i;
                                                Random r = new Random();

                                                for (i = 0; i < 4; i++)
                                                {
                                                    rnumber = rnumber + Convert.ToString(r.Next(1, 9));
                                                }

                                                string msg = "[멤버십]" +
                                                              System.Environment.NewLine + "회원코드: " + v.CtCode + System.Environment.NewLine + "비밀번호: " + "N" + rnumber +
                                                              System.Environment.NewLine + "문의)" + sendphone;

                                                dbSMS.Open();
                                                SqlCommand cmdSMS = new SqlCommand();
                                                cmdSMS.Connection = dbSMS;
                                                cmdSMS.CommandType = CommandType.Text;
                                                cmdSMS.CommandText = @"INSERT INTO SDK_SMS_SEND ( USER_ID, SMS_MSG, NOW_DATE, SCHEDULE_TYPE, SEND_DATE, CALLBACK, DEST_INFO, RESERVED1)" +
                                                                      "VALUES('jangbogo1310', @msg, replace(replace(replace(CONVERT(VARCHAR(19), getdate(), 120),'-',''),' ',''),':',''),0, " +
                                                                      "replace(replace(replace(CONVERT(VARCHAR(19), getdate(), 120),'-',''),' ',''),':',''), @callback, @phone,@etc)";

                                                cmdSMS.Parameters.AddWithValue("@phone", v.CtCode + "^" + sMobileSrc);
                                                cmdSMS.Parameters.AddWithValue("@callback",sendphone);
                                                cmdSMS.Parameters.AddWithValue("@msg", msg);
                                                cmdSMS.Parameters.AddWithValue("@etc",v.JoinLocation);
                                                cmdSMS.ExecuteNonQuery();
                                            }
                                            catch (Exception ex)
                                            {
                                                ModelState.AddModelError("", ex.Message);
                                                return View(c);
                                            }

                                        }

                                    }
                                    catch (Exception ex)
                                    {
                                        //
                                    }
                                }
                            }

                            v.CtPwd = zenFramework.Cryptogram.Cipher.Encrypt("N" + rnumber, v.CtCode);
                            db.SaveChanges();
                            return RedirectToAction("Message", "Home", new { gbn = "2", pCtCode = "" });
                        }
                        else
                        {
                            //
                        }

                    }

                }
                catch (InvalidOperationException ex)
                {
                    //
                }

            }
            return View(c);
        }

        //개인회원
        public ActionResult ConfirmMember2()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ConfirmMember2(table_Corp_Customer_src2 c, string returnUrl)
        {

            if (ModelState.IsValid) 
            {
                try
                {
                    using (CustomerModelEntities db = new CustomerModelEntities())
                    {
                        var sMobileSrc = c.Mobile_src;
                        sMobileSrc = sMobileSrc.ToString().Replace("-", "");
                        var v = db.table_Corp_Customer.Where(m => m.Mobile.Replace("-", "").Equals(sMobileSrc) && m.IsStatus.Equals("1")).FirstOrDefault();
                        if (v != null)
                        {
                            string rnumber = "";
                            using (SqlConnection dbCon = new SqlConnection(WebConfigurationManager.ConnectionStrings["Source"].ConnectionString))
                            {
                                string sql = "select top 1 Mobile as [phone] from table_corp where corpcode='JangBoGo'";

                                using (SqlCommand cmd = new SqlCommand(sql, dbCon))
                                {
                                    try
                                    {
                                        dbCon.Open();
                                        string sendphone = "";

                                        using (SqlDataReader rdr = cmd.ExecuteReader())
                                        {
                                            while (rdr.Read())
                                            {
                                                sendphone = rdr["phone"].ToString().Replace("-", "");

                                                if (sendphone.Length > 8)
                                                {
                                                    String.Format("{0: 0##-###-####}", Convert.ToInt32(sendphone));
                                                }

                                            }
                                        }

                                        /*문자발송 등록***************************************************************************************************/
                                        using (SqlConnection dbSMS = new SqlConnection(WebConfigurationManager.ConnectionStrings["SMS"].ConnectionString))
                                        {

                                            try
                                            {
                                                int i;
                                                Random r = new Random();

                                                for (i = 0; i < 4; i++)
                                                {
                                                    rnumber = rnumber + Convert.ToString(r.Next(1, 9));
                                                }

                                                string msg = "[멤버십]" +
                                                              System.Environment.NewLine + "회원코드: " + v.CtCode + System.Environment.NewLine + "비밀번호: " + "N" + rnumber +
                                                              System.Environment.NewLine + "문의)" + sendphone;

                                                dbSMS.Open();
                                                SqlCommand cmdSMS = new SqlCommand();
                                                cmdSMS.Connection = dbSMS;
                                                cmdSMS.CommandType = CommandType.Text;
                                                cmdSMS.CommandText = @"INSERT INTO SDK_SMS_SEND ( USER_ID, SMS_MSG, NOW_DATE, SCHEDULE_TYPE, SEND_DATE, CALLBACK, DEST_INFO, RESERVED1)" +
                                                                      "VALUES('jangbogo1310', @msg, replace(replace(replace(CONVERT(VARCHAR(19), getdate(), 120),'-',''),' ',''),':',''),0, " +
                                                                      "replace(replace(replace(CONVERT(VARCHAR(19), getdate(), 120),'-',''),' ',''),':',''), @callback, @phone, @etc)";

                                                cmdSMS.Parameters.AddWithValue("@phone", v.CtCode + "^" + sMobileSrc);
                                                cmdSMS.Parameters.AddWithValue("@callback", sendphone);
                                                cmdSMS.Parameters.AddWithValue("@msg", msg);
                                                cmdSMS.Parameters.AddWithValue("@etc", v.JoinLocation);
                                                cmdSMS.ExecuteNonQuery();
                                            }
                                            catch (Exception ex)
                                            {
                                                ModelState.AddModelError("", ex.Message);
                                                return View(c);
                                            }

                                        }

                                    }
                                    catch (Exception ex)
                                    {
                                        //
                                    }
                                }
                            }

                            v.CtPwd = zenFramework.Cryptogram.Cipher.Encrypt("N" + rnumber, v.CtCode);
                            db.SaveChanges();
                            return RedirectToAction("Message", "Home", new { gbn = "2", pCtCode = "" });
                        }
                        else
                        {
                            //
                        }

                    }

                }
                catch (InvalidOperationException ex)
                {
                    //
                }

            }
            return View(c);
        }

        //이용약관
        public ActionResult Policy()
        {
            return View();
        }

        //개인정보처리방침
        public ActionResult Policy2()
        {
            return View();
        }

        //결제
        public ActionResult GetBarcode(string Pctcode)
        {
            try
            {
                using (CustomerModelEntities db = new CustomerModelEntities())
                {
                    string rtnBarocde = "";
                    string membercode = "";
                    var v = db.table_Corp_Customer.Where(m => m.CtCode.Equals(Pctcode)).FirstOrDefault();
                    if (v != null)
                    {
                        if (v.PayKey != null && v.PayKey != "")
                        {
                            rtnBarocde = zenFramework.Cryptogram.Decipher.Decrypt(v.PayKey, v.CtCode);
                            return Content(rtnBarocde);
                        }
                        else
                        {
                            membercode = v.CtCode.ToString() + "00";
                            membercode = membercode.Substring(0, 8);
                            rtnBarocde = "M" + membercode + DateTime.Now.ToString("HHmm");
                            v.PayKey = zenFramework.Cryptogram.Cipher.Encrypt(rtnBarocde, v.CtCode);
                            db.SaveChanges();
                            return Content(rtnBarocde);
                        }
                    }
                    else
                    {
                        return Content("error");
                    }
                }
            }
            catch (InvalidOperationException ex)
            {
                return Content("error");
            }
        }

        //결제정보합계
        public ActionResult PaySum()
        {
            return View();
        }

        //결제정보조회  - 합계
        public ActionResult PaySumData(int pageindex, int pageSize)
        {
            try
            {
                using (ProcPaySumEntities db = new ProcPaySumEntities())
                {

                    HttpCookie cookie = Request.Cookies["Login"];
                    string ctcode = "";

                    if (cookie != null)
                    {
                        ctcode = HttpUtility.UrlDecode(cookie.Values["CtCode"]);
                    }
                    else
                    {
                        return RedirectToAction("Login", "Home");
                    }

                    if (pageindex > 0){
                        System.Threading.Thread.Sleep(3000);
                    }
                        var query = (from c in db.Ireon_Customer_Sale_List(null, "JangBoGo", ctcode)
                                        orderby c.RegDate descending, c.StorageName, c.TotalSalePrice, c.JangPay, c.StCode, c.SmCode
                                        select c)
                                     .Skip(pageindex * pageSize)
                                     .Take(pageSize);
                        return Json(new {JSONList = query.ToList()}, JsonRequestBehavior.AllowGet);

                }

            }
            catch (InvalidOperationException ex)
            {
                return Content("error");
            }

        }

        //결제정보조회 - 결제수단
        public ActionResult PaySumDataCharge(string SmCode)
        {
            try
            {
                using (ProcPaySumChargeEntities db = new ProcPaySumChargeEntities())
                {
                    HttpCookie cookie = Request.Cookies["Login"];

                    if (cookie != null)
                    {
                       //
                    }
                    else
                    {
                        return RedirectToAction("Login", "Home");
                    }

                    var query = (from c in db.Ireon_Sale_Pos_Charge_Info(null, "JangBoGo", SmCode)
                                 orderby c.Seq ascending, c.Seq, c.ChargeGubunName, c.ChargeTotal
                                 select c);
                    return Json(new { JSONList = query.ToList() }, JsonRequestBehavior.AllowGet);
                }
            }
            catch (InvalidOperationException ex)
            {
                return Content("error");
            }
        }
        //end

        //결제정보조회 - 상품정보
        public ActionResult PaySumDataProdList(string SmCode)
        {
            try
            {
                using (ProcPaySumPordListEntities db = new ProcPaySumPordListEntities())
                {
                    HttpCookie cookie = Request.Cookies["Login"];

                    if (cookie != null)
                    {
                        //
                    }
                    else
                    {
                        return RedirectToAction("Login", "Home");
                    }

                    var query = (from c in db.Ireon_Sale_Pos_Product_Info(null, "JangBoGo", SmCode)
                                 orderby c.Idx ascending, c.ProductName, c.UnitPrice, c.StockCnt, c.SaleTotal
                                 select c);
                    return Json(new { JSONList = query.ToList() }, JsonRequestBehavior.AllowGet);
                }
            }
            catch (InvalidOperationException ex)
            {
                return Content("error");
            }
        }
        //end

        //사업자등록증 업로드
        public ActionResult UploadImg()
        {
            return View();
        }

        //이미지 경로 업데이트
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult FileUpload(HttpPostedFileBase postedFile)
        {

            if (postedFile == null)
            {
                return RedirectToAction("Message", "Home", new { gbn = "9" });
            }

            string filename = "";

            if (postedFile.ContentType == "image/jpeg" || postedFile.ContentType == "image/png" || postedFile.ContentType == "image/gif")
            {
                if (postedFile.ContentType == "image/jpeg") 
                {
                    filename = ".jpg";
                }
                else if (postedFile.ContentType == "image/png")
                {
                    filename = ".png";
                }
                else if (postedFile.ContentType == "image/gif") 
                {
                    filename = ".gif";
                }
            }
            else
            {
                return RedirectToAction("Message", "Home", new { gbn = "10" });
            }

            try
            {
                using (CustomerModelEntities db = new CustomerModelEntities())
                {

                    HttpCookie cookie = Request.Cookies["Login"];
                    string ctcode = "";

                    if (cookie != null)
                    {
                        ctcode = HttpUtility.UrlDecode(cookie.Values["CtCode"]);
                    }
                    else
                    {
                        return RedirectToAction("Login", "Home");
                    }

                    var v = db.table_Corp_Customer.Where(m => m.CtCode.Equals(ctcode)).FirstOrDefault();
                    if (v != null)
                    {

                        string imgupyn = "";
                        imgupyn = v.IsCorpImg;

                        if (imgupyn == "1")
                        {
                            return RedirectToAction("Message", "Home", new { gbn = "12" });
                        }

                        string path = Server.MapPath("~/Uploads/" + DateTime.Now.ToString("yyyy\\/MMdd") + "/");

                        if (!Directory.Exists(path))
                        {
                            Directory.CreateDirectory(path);
                        }

                        postedFile.SaveAs(path + ctcode + filename);

                        if (!System.IO.File.Exists(path + ctcode + filename))
                        {
                            return RedirectToAction("Message", "Home", new { gbn = "10" });
                        }

                        path = "http://pay.jangerp.com" + "/Uploads/" + DateTime.Now.ToString("yyyy\\/MMdd") + "/";
                        v.CorpImgUrl = path + ctcode + filename;
                        v.IsCorpImg = "2";  //기본 '2', 확인 및 확정 '1'
                        db.SaveChanges();

                        return RedirectToAction("Message", "Home", new { gbn = "7" });

                    }
                    else
                    {
                        return RedirectToAction("Message", "Home", new { gbn = "8", pCtCode = "" });
                    }

                }

            }
            catch (InvalidOperationException ex)
            {
                return Content("error");
            }
        }

    }
}